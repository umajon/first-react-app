import "./Heading.css"

export const Heading = ({ text }) => {
    return (
        <h1 classname = "h1">{text}</h1>
    )
}


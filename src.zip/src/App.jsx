
import './App.css'
import { loginPage } from './pages/loginPage';

function App() {


  return (
    <>
     <loginPage/>
    </>
  )
}

export default App